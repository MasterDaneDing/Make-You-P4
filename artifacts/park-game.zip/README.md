# My Adventure in the Park - Interactive HTML5 Storybook

## How to Host on GitHub Pages (Takes 60 Seconds)
1. Create a new public repository on GitHub (e.g., `interactive-park-book`).
2. Upload `index.html` from this ZIP file to the root of your repository (and optionally upload your `Interactive Book` subfolders `Kids-play-together-21 (1)/`, `Kids-say-sorry-21/`, `kids arguing/`, and `Friends Song (1).mp3` through `Friends Song (5).mp3` alongside `index.html`).
3. In your GitHub repository, go to **Settings** -> **Pages**.
4. Under **Build and deployment** -> **Branch**, select `main` (or `master`) and `/ (root)`, then click **Save**.
5. Your interactive book will be live at `https://<your-github-username>.github.io/<repository-name>/`!
